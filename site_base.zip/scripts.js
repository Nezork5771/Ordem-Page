
function enviarAlerta() {
    alert('Todos os agentes foram alertados!');
}
