
const validUsers = {
    "agente": "senha123",
    "lider": "senha456"
};

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');

    if (validUsers[username] && validUsers[username] === password) {
        localStorage.setItem('loggedInUser', username);
        window.location.href = 'index.html';
        return false;
    } else {
        errorMessage.textContent = 'Usuário ou senha inválidos';
        return false;
    }
}

function checkLogin() {
    const loggedInUser = localStorage.getItem('loggedInUser');
    if (!loggedInUser) {
        window.location.href = 'login.html';
    }
}

function logout() {
    localStorage.removeItem('loggedInUser');
    window.location.href = 'login.html';
}

function showLeaderPage() {
    const loggedInUser = localStorage.getItem('loggedInUser');
    if (loggedInUser === 'lider') {
        document.getElementById('leader-link').style.display = 'inline';
    }
}
